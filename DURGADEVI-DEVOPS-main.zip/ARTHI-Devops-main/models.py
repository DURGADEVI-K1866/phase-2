from datetime import datetime
from app import db


class ScanResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    scan_type = db.Column(db.String(20), nullable=False)  # 'sonarqube' or 'trivy'
    project_name = db.Column(db.String(100), nullable=False)
    scan_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), nullable=False)  # 'success', 'failure', 'in_progress'
    raw_result = db.Column(db.Text)  # JSON string of full scan results
    
    # Summary metrics
    critical_issues = db.Column(db.Integer, default=0)
    high_issues = db.Column(db.Integer, default=0)
    medium_issues = db.Column(db.Integer, default=0)
    low_issues = db.Column(db.Integer, default=0)
    
    def __repr__(self):
        return f"<ScanResult {self.scan_type}:{self.project_name} {self.scan_date}>"


class SonarQubeConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    url = db.Column(db.String(255), nullable=False)
    token = db.Column(db.String(255), nullable=False)
    quality_gate_id = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<SonarQubeConfig {self.name}>"


class TrivyConfig(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    severity_levels = db.Column(db.String(100), default="CRITICAL,HIGH")  # Comma-separated list of severity levels to report
    image_registry = db.Column(db.String(255))
    registry_username = db.Column(db.String(100))
    registry_password = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<TrivyConfig {self.name}>"


class Pipeline(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    ci_type = db.Column(db.String(50), nullable=False)  # 'github', 'gitlab', 'jenkins'
    repository_url = db.Column(db.String(255))
    branch = db.Column(db.String(100), default="main")
    sonarqube_config_id = db.Column(db.Integer, db.ForeignKey('sonar_qube_config.id'), nullable=True)
    trivy_config_id = db.Column(db.Integer, db.ForeignKey('trivy_config.id'), nullable=True)
    config_file = db.Column(db.Text)  # The generated pipeline configuration
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sonarqube_config = db.relationship('SonarQubeConfig', backref='pipelines')
    trivy_config = db.relationship('TrivyConfig', backref='pipelines')
    
    def __repr__(self):
        return f"<Pipeline {self.name} ({self.ci_type})>"
