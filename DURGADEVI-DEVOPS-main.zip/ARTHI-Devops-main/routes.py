import json
import logging
from datetime import datetime, timedelta
from flask import render_template, request, redirect, url_for, flash, jsonify

from app import app, db
from models import ScanResult, SonarQubeConfig, TrivyConfig, Pipeline
from utils.sonarqube_client import SonarQubeClient
from utils.trivy_client import TrivyClient
from utils.pipeline_generator import generate_pipeline_config
from utils.report_generator import generate_report

logger = logging.getLogger(__name__)

@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    # Get summary of recent scans
    recent_scans = ScanResult.query.order_by(ScanResult.scan_date.desc()).limit(10).all()
    
    # Get count of issues by severity
    seven_days_ago = datetime.utcnow() - timedelta(days=7)
    sonarqube_issues = ScanResult.query.filter(
        ScanResult.scan_type == 'sonarqube',
        ScanResult.scan_date >= seven_days_ago
    ).all()
    
    trivy_issues = ScanResult.query.filter(
        ScanResult.scan_type == 'trivy',
        ScanResult.scan_date >= seven_days_ago
    ).all()
    
    # Aggregate results for charts
    sonarqube_summary = {
        'critical': sum(scan.critical_issues for scan in sonarqube_issues),
        'high': sum(scan.high_issues for scan in sonarqube_issues),
        'medium': sum(scan.medium_issues for scan in sonarqube_issues),
        'low': sum(scan.low_issues for scan in sonarqube_issues)
    }
    
    trivy_summary = {
        'critical': sum(scan.critical_issues for scan in trivy_issues),
        'high': sum(scan.high_issues for scan in trivy_issues),
        'medium': sum(scan.medium_issues for scan in trivy_issues),
        'low': sum(scan.low_issues for scan in trivy_issues)
    }
    
    return render_template(
        'dashboard.html',
        recent_scans=recent_scans,
        sonarqube_summary=sonarqube_summary,
        trivy_summary=trivy_summary
    )

@app.route('/sonarqube')
def sonarqube():
    configs = SonarQubeConfig.query.all()
    scans = ScanResult.query.filter_by(scan_type='sonarqube').order_by(ScanResult.scan_date.desc()).limit(20).all()
    return render_template('sonarqube.html', configs=configs, scans=scans)

@app.route('/sonarqube/config', methods=['POST'])
def add_sonarqube_config():
    try:
        name = request.form.get('name')
        url = request.form.get('url')
        token = request.form.get('token')
        quality_gate_id = request.form.get('quality_gate_id', '')
        
        if not all([name, url, token]):
            flash('Name, URL, and token are required', 'danger')
            return redirect(url_for('sonarqube'))
        
        config = SonarQubeConfig(
            name=name,
            url=url,
            token=token,
            quality_gate_id=quality_gate_id
        )
        db.session.add(config)
        db.session.commit()
        flash('SonarQube configuration added successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error adding SonarQube config: {str(e)}")
        flash(f'Failed to add SonarQube configuration: {str(e)}', 'danger')
    
    return redirect(url_for('sonarqube'))

@app.route('/sonarqube/config/<int:config_id>', methods=['POST'])
def update_sonarqube_config(config_id):
    try:
        config = SonarQubeConfig.query.get_or_404(config_id)
        config.name = request.form.get('name', config.name)
        config.url = request.form.get('url', config.url)
        
        # Only update token if one is provided
        token = request.form.get('token')
        if token:
            config.token = token
            
        config.quality_gate_id = request.form.get('quality_gate_id', config.quality_gate_id)
        config.is_active = 'is_active' in request.form
        config.updated_at = datetime.utcnow()
        
        db.session.commit()
        flash('SonarQube configuration updated successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating SonarQube config: {str(e)}")
        flash(f'Failed to update SonarQube configuration: {str(e)}', 'danger')
    
    return redirect(url_for('sonarqube'))

@app.route('/sonarqube/config/<int:config_id>/delete', methods=['POST'])
def delete_sonarqube_config(config_id):
    try:
        config = SonarQubeConfig.query.get_or_404(config_id)
        db.session.delete(config)
        db.session.commit()
        flash('SonarQube configuration deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting SonarQube config: {str(e)}")
        flash(f'Failed to delete SonarQube configuration: {str(e)}', 'danger')
    
    return redirect(url_for('sonarqube'))

@app.route('/sonarqube/scan', methods=['POST'])
def run_sonarqube_scan():
    try:
        config_id = request.form.get('config_id')
        project_name = request.form.get('project_name')
        
        if not config_id or not project_name:
            flash('Config and project name are required', 'danger')
            return redirect(url_for('sonarqube'))
        
        config = SonarQubeConfig.query.get_or_404(config_id)
        client = SonarQubeClient(config.url, config.token)
        
        # Create a scan record in progress state
        scan = ScanResult(
            scan_type='sonarqube',
            project_name=project_name,
            status='in_progress'
        )
        db.session.add(scan)
        db.session.commit()
        
        # Run the scan
        result = client.get_project_issues(project_name)
        
        # Parse and count issues by severity
        issues = result.get('issues', [])
        critical = sum(1 for issue in issues if issue.get('severity') == 'CRITICAL')
        high = sum(1 for issue in issues if issue.get('severity') == 'MAJOR')
        medium = sum(1 for issue in issues if issue.get('severity') == 'MINOR')
        low = sum(1 for issue in issues if issue.get('severity') in ['INFO', 'BLOCKER'])
        
        # Update the scan record
        scan.status = 'success'
        scan.raw_result = json.dumps(result)
        scan.critical_issues = critical
        scan.high_issues = high
        scan.medium_issues = medium
        scan.low_issues = low
        db.session.commit()
        
        flash('SonarQube scan completed successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error running SonarQube scan: {str(e)}")
        
        # Create failure record
        scan = ScanResult(
            scan_type='sonarqube',
            project_name=project_name,
            status='failure',
            raw_result=json.dumps({"error": str(e)})
        )
        db.session.add(scan)
        db.session.commit()
        
        flash(f'Failed to run SonarQube scan: {str(e)}', 'danger')
    
    return redirect(url_for('sonarqube'))

@app.route('/trivy')
def trivy():
    configs = TrivyConfig.query.all()
    scans = ScanResult.query.filter_by(scan_type='trivy').order_by(ScanResult.scan_date.desc()).limit(20).all()
    return render_template('trivy.html', configs=configs, scans=scans)

@app.route('/trivy/config', methods=['POST'])
def add_trivy_config():
    try:
        name = request.form.get('name')
        severity_levels = request.form.get('severity_levels', 'CRITICAL,HIGH')
        image_registry = request.form.get('image_registry', '')
        registry_username = request.form.get('registry_username', '')
        registry_password = request.form.get('registry_password', '')
        
        if not name:
            flash('Name is required', 'danger')
            return redirect(url_for('trivy'))
        
        config = TrivyConfig(
            name=name,
            severity_levels=severity_levels,
            image_registry=image_registry,
            registry_username=registry_username,
            registry_password=registry_password
        )
        db.session.add(config)
        db.session.commit()
        flash('Trivy configuration added successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error adding Trivy config: {str(e)}")
        flash(f'Failed to add Trivy configuration: {str(e)}', 'danger')
    
    return redirect(url_for('trivy'))

@app.route('/trivy/config/<int:config_id>', methods=['POST'])
def update_trivy_config(config_id):
    try:
        config = TrivyConfig.query.get_or_404(config_id)
        config.name = request.form.get('name', config.name)
        config.severity_levels = request.form.get('severity_levels', config.severity_levels)
        config.image_registry = request.form.get('image_registry', config.image_registry)
        config.registry_username = request.form.get('registry_username', config.registry_username)
        
        # Only update password if provided
        password = request.form.get('registry_password')
        if password:
            config.registry_password = password
            
        config.is_active = 'is_active' in request.form
        config.updated_at = datetime.utcnow()
        
        db.session.commit()
        flash('Trivy configuration updated successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating Trivy config: {str(e)}")
        flash(f'Failed to update Trivy configuration: {str(e)}', 'danger')
    
    return redirect(url_for('trivy'))

@app.route('/trivy/config/<int:config_id>/delete', methods=['POST'])
def delete_trivy_config(config_id):
    try:
        config = TrivyConfig.query.get_or_404(config_id)
        db.session.delete(config)
        db.session.commit()
        flash('Trivy configuration deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting Trivy config: {str(e)}")
        flash(f'Failed to delete Trivy configuration: {str(e)}', 'danger')
    
    return redirect(url_for('trivy'))

@app.route('/trivy/scan', methods=['POST'])
def run_trivy_scan():
    try:
        config_id = request.form.get('config_id')
        image_name = request.form.get('image_name')
        
        if not config_id or not image_name:
            flash('Config and image name are required', 'danger')
            return redirect(url_for('trivy'))
        
        config = TrivyConfig.query.get_or_404(config_id)
        client = TrivyClient(
            severity=config.severity_levels,
            registry=config.image_registry,
            username=config.registry_username,
            password=config.registry_password
        )
        
        # Create a scan record in progress state
        scan = ScanResult(
            scan_type='trivy',
            project_name=image_name,
            status='in_progress'
        )
        db.session.add(scan)
        db.session.commit()
        
        # Run the scan
        result = client.scan_image(image_name)
        
        # Parse and count vulnerabilities by severity
        vulnerabilities = result.get('Results', [])
        all_vulns = []
        for res in vulnerabilities:
            if 'Vulnerabilities' in res:
                all_vulns.extend(res['Vulnerabilities'])
        
        critical = sum(1 for vuln in all_vulns if vuln.get('Severity') == 'CRITICAL')
        high = sum(1 for vuln in all_vulns if vuln.get('Severity') == 'HIGH')
        medium = sum(1 for vuln in all_vulns if vuln.get('Severity') == 'MEDIUM')
        low = sum(1 for vuln in all_vulns if vuln.get('Severity') in ['LOW', 'UNKNOWN'])
        
        # Update the scan record
        scan.status = 'success'
        scan.raw_result = json.dumps(result)
        scan.critical_issues = critical
        scan.high_issues = high
        scan.medium_issues = medium
        scan.low_issues = low
        db.session.commit()
        
        flash('Trivy scan completed successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error running Trivy scan: {str(e)}")
        
        # Create failure record
        scan = ScanResult(
            scan_type='trivy',
            project_name=image_name,
            status='failure',
            raw_result=json.dumps({"error": str(e)})
        )
        db.session.add(scan)
        db.session.commit()
        
        flash(f'Failed to run Trivy scan: {str(e)}', 'danger')
    
    return redirect(url_for('trivy'))

@app.route('/pipelines')
def pipelines():
    pipelines = Pipeline.query.all()
    sonarqube_configs = SonarQubeConfig.query.all()
    trivy_configs = TrivyConfig.query.all()
    return render_template('settings.html', 
                          pipelines=pipelines, 
                          sonarqube_configs=sonarqube_configs,
                          trivy_configs=trivy_configs)

@app.route('/pipelines/create', methods=['POST'])
def create_pipeline():
    try:
        name = request.form.get('name')
        ci_type = request.form.get('ci_type')
        repository_url = request.form.get('repository_url', '')
        branch = request.form.get('branch', 'main')
        sonarqube_config_id = request.form.get('sonarqube_config_id')
        trivy_config_id = request.form.get('trivy_config_id')
        
        if not all([name, ci_type]):
            flash('Name and CI/CD type are required', 'danger')
            return redirect(url_for('pipelines'))
        
        # Convert empty strings to None
        sonarqube_config_id = int(sonarqube_config_id) if sonarqube_config_id else None
        trivy_config_id = int(trivy_config_id) if trivy_config_id else None
        
        # Generate the pipeline configuration
        sonarqube_config = SonarQubeConfig.query.get(sonarqube_config_id) if sonarqube_config_id else None
        trivy_config = TrivyConfig.query.get(trivy_config_id) if trivy_config_id else None
        
        config_file = generate_pipeline_config(
            ci_type=ci_type,
            sonarqube_config=sonarqube_config,
            trivy_config=trivy_config,
            repository=repository_url,
            branch=branch
        )
        
        pipeline = Pipeline(
            name=name,
            ci_type=ci_type,
            repository_url=repository_url,
            branch=branch,
            sonarqube_config_id=sonarqube_config_id,
            trivy_config_id=trivy_config_id,
            config_file=config_file
        )
        db.session.add(pipeline)
        db.session.commit()
        flash('Pipeline configuration created successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating pipeline: {str(e)}")
        flash(f'Failed to create pipeline: {str(e)}', 'danger')
    
    return redirect(url_for('pipelines'))

@app.route('/pipelines/<int:pipeline_id>')
def view_pipeline(pipeline_id):
    pipeline = Pipeline.query.get_or_404(pipeline_id)
    return jsonify({
        'name': pipeline.name,
        'ci_type': pipeline.ci_type,
        'config_file': pipeline.config_file
    })

@app.route('/pipelines/<int:pipeline_id>/delete', methods=['POST'])
def delete_pipeline(pipeline_id):
    try:
        pipeline = Pipeline.query.get_or_404(pipeline_id)
        db.session.delete(pipeline)
        db.session.commit()
        flash('Pipeline deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting pipeline: {str(e)}")
        flash(f'Failed to delete pipeline: {str(e)}', 'danger')
    
    return redirect(url_for('pipelines'))

@app.route('/documentation')
def documentation():
    return render_template('documentation.html')

@app.route('/api/scan-results')
def api_scan_results():
    days = request.args.get('days', 7, type=int)
    period_start = datetime.utcnow() - timedelta(days=days)
    
    sonarqube_scans = ScanResult.query.filter(
        ScanResult.scan_type == 'sonarqube',
        ScanResult.scan_date >= period_start
    ).all()
    
    trivy_scans = ScanResult.query.filter(
        ScanResult.scan_type == 'trivy',
        ScanResult.scan_date >= period_start
    ).all()
    
    # Format dates for chart
    dates = [
        (datetime.utcnow() - timedelta(days=i)).strftime('%Y-%m-%d')
        for i in range(days, -1, -1)
    ]
    
    # Group scan counts by date
    sonarqube_data = {date: 0 for date in dates}
    trivy_data = {date: 0 for date in dates}
    
    for scan in sonarqube_scans:
        date_key = scan.scan_date.strftime('%Y-%m-%d')
        if date_key in sonarqube_data:
            sonarqube_data[date_key] += 1
            
    for scan in trivy_scans:
        date_key = scan.scan_date.strftime('%Y-%m-%d')
        if date_key in trivy_data:
            trivy_data[date_key] += 1
            
    return jsonify({
        'dates': dates,
        'sonarqube_counts': list(sonarqube_data.values()),
        'trivy_counts': list(trivy_data.values()),
    })

@app.route('/api/severity-summary')
def api_severity_summary():
    period_start = datetime.utcnow() - timedelta(days=30)
    
    # Get all scans in the last 30 days
    scans = ScanResult.query.filter(
        ScanResult.scan_date >= period_start,
        ScanResult.status == 'success'
    ).all()
    
    # Aggregate by scan type and severity
    sonarqube = {
        'critical': sum(scan.critical_issues for scan in scans if scan.scan_type == 'sonarqube'),
        'high': sum(scan.high_issues for scan in scans if scan.scan_type == 'sonarqube'),
        'medium': sum(scan.medium_issues for scan in scans if scan.scan_type == 'sonarqube'),
        'low': sum(scan.low_issues for scan in scans if scan.scan_type == 'sonarqube')
    }
    
    trivy = {
        'critical': sum(scan.critical_issues for scan in scans if scan.scan_type == 'trivy'),
        'high': sum(scan.high_issues for scan in scans if scan.scan_type == 'trivy'),
        'medium': sum(scan.medium_issues for scan in scans if scan.scan_type == 'trivy'),
        'low': sum(scan.low_issues for scan in scans if scan.scan_type == 'trivy')
    }
    
    return jsonify({
        'sonarqube': sonarqube,
        'trivy': trivy
    })

@app.route('/scan/<int:scan_id>')
def view_scan_details(scan_id):
    scan = ScanResult.query.get_or_404(scan_id)
    report = generate_report(scan)
    return render_template('scan_details.html', scan=scan, report=report)
